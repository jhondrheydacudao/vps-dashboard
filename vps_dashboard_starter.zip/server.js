const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const path = require('path');
require('dotenv').config();

const ADMIN_EMAIL = process.env.ADMIN_EMAIL;

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

let users = {}; // Simulate DB for this example

passport.serializeUser((user, done) => {
  done(null, user.discord_id);
});

passport.deserializeUser((id, done) => {
  done(null, users[id] || null);
});

passport.use(new DiscordStrategy({
  clientID: process.env.DISCORD_CLIENT_ID,
  clientSecret: process.env.DISCORD_CLIENT_SECRET,
  callbackURL: process.env.DISCORD_REDIRECT_URI,
  scope: ['identify', 'email']
}, (accessToken, refreshToken, profile, done) => {
  const isAdmin = profile.email === ADMIN_EMAIL;

  users[profile.id] = {
    discord_id: profile.id,
    username: profile.username,
    email: profile.email,
    avatar: profile.avatar,
    is_admin: isAdmin
  };
  return done(null, users[profile.id]);
}));

app.get('/', (req, res) => {
  res.render('index', { user: req.user });
});

app.get('/login', passport.authenticate('discord'));

app.get('/auth/discord/callback', passport.authenticate('discord', {
  failureRedirect: '/'
}), (req, res) => {
  res.redirect('/');
});

app.get('/admin', (req, res) => {
  if (!req.user || !req.user.is_admin) {
    return res.status(403).send('Access denied');
  }
  res.render('admin', { user: req.user });
});

app.get('/logout', (req, res) => {
  req.logout(() => {
    res.redirect('/');
  });
});

app.listen(3000, () => {
  console.log('Server started on http://localhost:3000');
});
